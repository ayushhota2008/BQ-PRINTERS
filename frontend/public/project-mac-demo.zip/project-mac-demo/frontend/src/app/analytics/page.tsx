"use client";

import { useState, useEffect } from "react";
import Sidebar from "@/components/Sidebar";
import TopHeader from "@/components/TopHeader";
import { BarChart2, Clock, Users, Printer, TrendingUp } from "lucide-react";
import { listSavedDatasets, getDatasetById } from "@/lib/api";

export default function AnalyticsPage() {
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    async function loadData() {
      try {
        const datasets = await listSavedDatasets();
        if (datasets.length > 0) {
          const details = await getDatasetById(datasets[0].id);
          setData(details.calculations);
        }
      } catch (err) {
        console.error("Failed to load analytics data:", err);
      }
    }
    loadData();
  }, []);

  const rates = data?.duration_adjusted_rates || {
    "9 AM–11 AM": 36.71,
    "11 AM–1 PM": 52.0,
    "1 PM–4 PM": 19.9,
    "4 PM–6 PM": 12.86,
  };

  return (
    <div className="app-container">
      <Sidebar />

      <main className="main-wrapper">
        <TopHeader />

        <div className="dashboard-content animate-fade-in" style={{ maxWidth: "1200px" }}>
          <div>
            <h1 style={{ fontSize: "22px", fontWeight: "800", color: "#0f172a" }}>
              Operational Analytics &amp; Service Intensities
            </h1>
            <p style={{ fontSize: "13px", color: "#64748b", marginTop: "2px" }}>
              Detailed rate-adjusted workloads, equipment load analysis, and labor hours allocation.
            </p>
          </div>

          {/* Time Slot Duration-Adjusted Rate Comparison */}
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">
                <Clock size={18} color="#e11d48" />
                Duration-Adjusted Customer Arrival Rates
              </h3>
            </div>
            <p style={{ fontSize: "13px", color: "#475569", marginBottom: "16px", lineHeight: "1.5" }}>
              Because time slots have unequal lengths (1 PM–4 PM is 3 hours while others are 2 hours), comparing raw orders can be misleading. Duration-adjusted rates measure customer intensity per operational hour:
            </p>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "14px" }}>
              {[
                { slot: "9 AM–11 AM", hours: 2, key: "9 AM–11 AM" },
                { slot: "11 AM–1 PM", hours: 2, key: "11 AM–1 PM", isPeak: true },
                { slot: "1 PM–4 PM", hours: 3, key: "1 PM–4 PM" },
                { slot: "4 PM–6 PM", hours: 2, key: "4 PM–6 PM" },
              ].map((item) => {
                const rate = rates[item.key] || 0;
                return (
                  <div
                    key={item.slot}
                    style={{
                      background: item.isPeak ? "#fff1f2" : "#f8fafc",
                      border: item.isPeak ? "1px solid #fecdd3" : "1px solid #e2e8f0",
                      borderRadius: "10px",
                      padding: "16px",
                      textAlign: "center",
                    }}
                  >
                    <div style={{ fontSize: "12px", color: "#64748b", fontWeight: "700" }}>{item.slot}</div>
                    <div style={{ fontSize: "26px", fontWeight: "800", color: item.isPeak ? "#e11d48" : "#0f172a", margin: "6px 0" }}>
                      {rate} <span style={{ fontSize: "12px", fontWeight: "600", color: "#64748b" }}>req/hr</span>
                    </div>
                    <div style={{ fontSize: "11px", color: "#94a3b8" }}>Slot Duration: {item.hours} Hours</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Service Handling Labor Analysis */}
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">
                <Users size={18} color="#e11d48" />
                Service-Wise Staff Handling Minutes
              </h3>
            </div>

            <div style={{ overflowX: "auto" }}>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Service</th>
                    <th style={{ textAlign: "center" }}>Weekly Order Count</th>
                    <th style={{ textAlign: "center" }}>Assumed Handling Time</th>
                    <th style={{ textAlign: "right" }}>Total Labor Minutes</th>
                    <th style={{ textAlign: "right" }}>Total Labor Hours</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { name: "B&W Printing", orders: 918, time: "2 min/order", mins: 1836, hrs: 30.6 },
                    { name: "Colour Printing", orders: 319, time: "4 min/order", mins: 1276, hrs: 21.27 },
                    { name: "Binding", orders: 107, time: "8 min/order", mins: 856, hrs: 14.27 },
                    { name: "Photocopying", orders: 496, time: "2 min/order", mins: 992, hrs: 16.53 },
                  ].map((row) => (
                    <tr key={row.name}>
                      <td style={{ fontWeight: "700" }}>{row.name}</td>
                      <td style={{ textAlign: "center" }}>{row.orders}</td>
                      <td style={{ textAlign: "center", color: "#64748b" }}>{row.time}</td>
                      <td style={{ textAlign: "right", fontFamily: "var(--font-mono)", fontWeight: "600" }}>{row.mins} min</td>
                      <td style={{ textAlign: "right", fontFamily: "var(--font-mono)", fontWeight: "700", color: "#e11d48" }}>{row.hrs.toFixed(2)} hrs</td>
                    </tr>
                  ))}
                  <tr className="total-row">
                    <td>Total Order Handling</td>
                    <td style={{ textAlign: "center" }}>1,840</td>
                    <td style={{ textAlign: "center" }}>—</td>
                    <td style={{ textAlign: "right" }}>4,960 min</td>
                    <td style={{ textAlign: "right", color: "#e11d48" }}>82.67 hrs</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
