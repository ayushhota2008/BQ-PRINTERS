"use client";

import { useEffect, useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { Loader2, AlertCircle } from "lucide-react";
import Link from "next/link";

function AuthCallbackContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;

    async function handleAuthCallback() {
      try {
        const code = searchParams.get("code");
        const next = searchParams.get("next") || "/dashboard";

        // 1. If an authorization code was returned (PKCE flow), exchange it for a session
        if (code) {
          const { error } = await supabase.auth.exchangeCodeForSession(code);
          if (error) throw error;
          if (isMounted) router.replace(next);
          return;
        }

        // 2. Check if a session already exists (implicit flow or already signed in)
        const {
          data: { session },
          error: sessionError,
        } = await supabase.auth.getSession();
        if (sessionError) throw sessionError;

        if (session) {
          if (isMounted) router.replace(next);
          return;
        }

        // 3. Listen for auth state change in case the session is being extracted asynchronously from URL hash
        const { data: authListener } = supabase.auth.onAuthStateChange(
          (event, newSession) => {
            if (newSession && isMounted) {
              authListener.subscription.unsubscribe();
              router.replace(next);
            }
          }
        );

        // 4. Fallback timeout to redirect to dashboard after 3.5s
        const timeout = setTimeout(() => {
          authListener.subscription.unsubscribe();
          if (isMounted) {
            router.replace(next);
          }
        }, 3500);

        return () => {
          clearTimeout(timeout);
          authListener.subscription.unsubscribe();
        };
      } catch (err: any) {
        if (isMounted) {
          console.error("Auth callback error:", err);
          setErrorMsg(err.message || "Failed to complete Google Sign-In.");
        }
      }
    }

    handleAuthCallback();

    return () => {
      isMounted = false;
    };
  }, [router, searchParams]);

  if (errorMsg) {
    return (
      <div
        style={{
          minHeight: "100vh",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          background: "#f8fafc",
          padding: "24px",
        }}
      >
        <div
          style={{
            maxWidth: "420px",
            width: "100%",
            background: "#ffffff",
            padding: "32px",
            borderRadius: "16px",
            border: "1px solid #fee2e2",
            textAlign: "center",
            boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.05)",
          }}
        >
          <AlertCircle size={44} color="#dc2626" style={{ margin: "0 auto 16px" }} />
          <h3
            style={{
              fontSize: "18px",
              fontWeight: "700",
              color: "#0f172a",
              marginBottom: "8px",
            }}
          >
            Google Authentication Failed
          </h3>
          <p
            style={{
              fontSize: "13px",
              color: "#64748b",
              lineHeight: "1.5",
              marginBottom: "20px",
            }}
          >
            {errorMsg}
          </p>
          <Link
            href="/login"
            style={{
              display: "inline-block",
              padding: "10px 22px",
              background: "#e11d48",
              color: "#ffffff",
              borderRadius: "8px",
              fontSize: "13px",
              fontWeight: "600",
              textDecoration: "none",
            }}
          >
            Back to Login
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        background: "linear-gradient(180deg, #f8fafc 0%, #f1f5f9 100%)",
        gap: "16px",
      }}
    >
      <Loader2 size={36} className="animate-spin" color="#e11d48" />
      <p style={{ fontSize: "14px", fontWeight: "600", color: "#475569" }}>
        Finalizing Google sign-in with Supabase...
      </p>
    </div>
  );
}

export default function AuthCallbackPage() {
  return (
    <Suspense
      fallback={
        <div
          style={{
            minHeight: "100vh",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: "#f8fafc",
          }}
        >
          <Loader2 size={36} className="animate-spin" color="#e11d48" />
        </div>
      }
    >
      <AuthCallbackContent />
    </Suspense>
  );
}

