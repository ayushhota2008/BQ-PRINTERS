"use client";

import Sidebar from "@/components/Sidebar";
import TopHeader from "@/components/TopHeader";
import InsightsRecommendations from "@/components/InsightsRecommendations";

export default function RecommendationsPage() {
  const defaultRecs = [
    {
      id: 1,
      title: "Stock More B&W Paper & Ink",
      description:
        "B&W Printing accounts for 49.89% of total demand. Ensure adequate stock of B&W paper and ink, especially before peak hours (11 AM – 1 PM).",
      category: "Inventory",
      priority: "High" as const,
    },
    {
      id: 2,
      title: "Plan Staff for Midday Rush",
      description:
        "The busiest time slot is 11 AM – 1 PM with a peak rate of 52.0 orders/hr. Schedule extra staff and keep high-speed printers pre-warmed during this period.",
      category: "Staffing",
      priority: "High" as const,
    },
    {
      id: 3,
      title: "Prepare for Colour Printing Growth",
      description:
        "Colour Printing represents 17.34% of volume but higher margin. Ensure Canon PIXMA MegaTank G670 ink tanks are regularly replenished.",
      category: "Operations",
      priority: "Medium" as const,
    },
    {
      id: 4,
      title: "Batch Low-Priority Binding in Afternoon",
      description:
        "Binding demand accounts for 5.82% of requests. Batch heavy spiral/comb binding during the 4 PM – 6 PM lull (12.86 orders/hr) to avoid operator bottlenecks.",
      category: "Workload",
      priority: "Low" as const,
    },
    {
      id: 5,
      title: "Footfall-Driven Cross-Service Marketing",
      description:
        "Principal Component Analysis shows 94.47% variance explained by a single dominant factor with positive loadings across all four services, confirming all services rise and fall together with general customer footfall.",
      category: "Marketing",
      priority: "Medium" as const,
    },
  ];

  return (
    <div className="app-container">
      <Sidebar />
      <main className="main-wrapper">
        <TopHeader lastUpdated="Today" />
        <div style={{ padding: "28px 36px 60px", maxWidth: "1200px", margin: "0 auto", width: "100%" }}>
          <div style={{ marginBottom: "20px" }}>
            <h2 style={{ fontSize: "22px", fontWeight: "800", color: "#0f172a" }}>
              Actionable Business Recommendations
            </h2>
            <p style={{ fontSize: "13px", color: "#64748b", marginTop: "4px" }}>
              Synthesized from your 7-day demand matrix, time slot arrival rates, and machine capacity ratios.
            </p>
          </div>
          <InsightsRecommendations recommendations={defaultRecs} />
        </div>
      </main>
    </div>
  );
}
