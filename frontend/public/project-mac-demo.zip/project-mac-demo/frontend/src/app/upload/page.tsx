"use client";

import { useState, useRef, useMemo } from "react";
import { useRouter } from "next/navigation";
import Sidebar from "@/components/Sidebar";
import TopHeader from "@/components/TopHeader";
import {
  UploadCloud,
  FileSpreadsheet,
  CheckCircle,
  AlertCircle,
  Loader2,
  ArrowRight,
  Download,
  Calendar,
  Printer,
  Clock,
  FileText,
  X,
} from "lucide-react";
import { analyzeCsvFile, fetchSampleCsv } from "@/lib/api";
import { ACADEMIC_SAMPLE_CSV } from "@/lib/constants";

export default function UploadPage() {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [datasetName, setDatasetName] = useState("Weekly Demand Dataset");
  const [weekLabel, setWeekLabel] = useState("Oct 24 – Oct 30, 2026");
  const [notes, setNotes] = useState("");
  const [rawCsvText, setRawCsvText] = useState("");
  const [file, setFile] = useState<File | null>(null);

  const [loading, setLoading] = useState(false);
  const [sampleLoading, setSampleLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  // Parse CSV rows for table preview
  const parsedRows = useMemo(() => {
    if (!rawCsvText.trim()) return [];
    const lines = rawCsvText.trim().split("\n");
    if (lines.length <= 1) return [];
    return lines.slice(1).map((line) => {
      const parts = line.split(",").map((s) => s.trim());
      const v1 = parseInt(parts[2] || "0", 10) || 0;
      const v2 = parseInt(parts[3] || "0", 10) || 0;
      const v3 = parseInt(parts[4] || "0", 10) || 0;
      const v4 = parseInt(parts[5] || "0", 10) || 0;
      return {
        day: parts[0] || "",
        service: parts[1] || "",
        s1: v1,
        s2: v2,
        s3: v3,
        s4: v4,
        total: v1 + v2 + v3 + v4,
      };
    });
  }, [rawCsvText]);

  // Download official CSV template
  const handleDownloadTemplate = () => {
    const blob = new Blob([ACADEMIC_SAMPLE_CSV], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "bq_printers_demand_template.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Load sample dataset
  const handleLoadSample = async () => {
    setSampleLoading(true);
    setError(null);
    try {
      let csvContent = "";
      try {
        csvContent = await fetchSampleCsv();
      } catch {
        csvContent = ACADEMIC_SAMPLE_CSV;
      }
      setRawCsvText(csvContent);
      const sampleBlob = new File([csvContent], "academic_benchmark_dataset.csv", {
        type: "text/csv",
      });
      setFile(sampleBlob);
      setDatasetName("Academic Benchmark Dataset (7 Days)");
      setWeekLabel("Week 1 (Academic Report Benchmark)");
      setSuccess("Academic report sample CSV loaded successfully (28 records across 7 days).");
    } catch (err: any) {
      setRawCsvText(ACADEMIC_SAMPLE_CSV);
      const sampleBlob = new File([ACADEMIC_SAMPLE_CSV], "academic_benchmark_dataset.csv", {
        type: "text/csv",
      });
      setFile(sampleBlob);
      setSuccess("Academic benchmark CSV loaded.");
    } finally {
      setSampleLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (selected) {
      setFile(selected);
      setError(null);
      setSuccess(null);
      const reader = new FileReader();
      reader.onload = (event) => {
        setRawCsvText((event.target?.result as string) || "");
      };
      reader.readAsText(selected);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const dropped = e.dataTransfer.files?.[0];
    if (dropped) {
      setFile(dropped);
      setError(null);
      setSuccess(null);
      const reader = new FileReader();
      reader.onload = (event) => {
        setRawCsvText((event.target?.result as string) || "");
      };
      reader.readAsText(dropped);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    let targetFile = file;
    if (!targetFile && rawCsvText.trim()) {
      targetFile = new File([rawCsvText.trim()], "uploaded_demand_data.csv", {
        type: "text/csv",
      });
    }

    if (!targetFile) {
      setError("Please choose a CSV file or paste raw CSV demand data to continue.");
      return;
    }

    setLoading(true);
    try {
      let assumptionsPayload: any = { notes };
      try {
        const stored = localStorage.getItem("bq_printers_assumptions");
        if (stored) {
          assumptionsPayload = { ...JSON.parse(stored), notes };
        }
      } catch {}

      const res = await analyzeCsvFile(
        targetFile,
        datasetName,
        weekLabel,
        true, // saveToSupabase
        assumptionsPayload,
        undefined,
        notes
      );

      setSuccess("Dataset analyzed and stored in Supabase PostgreSQL successfully! Redirecting to dashboard...");
      setTimeout(() => {
        router.push("/dashboard");
      }, 1200);
    } catch (err: any) {
      setError(err.message || "Failed to analyze CSV. Please verify column headers and structure.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app-container">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Page Area */}
      <main className="main-wrapper" style={{ position: "relative" }}>
        <TopHeader lastUpdated="Today" />

        <div style={{ padding: "28px 36px 60px", maxWidth: "1200px", margin: "0 auto", width: "100%" }}>
          {/* Subheader description */}
          <p style={{ fontSize: "13px", color: "#64748b", marginBottom: "24px" }}>
            Upload your 7-day CSV file to run matrix calculations, covariance analysis, printer capacity, and business recommendations.
          </p>

          {/* Form Card */}
          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "16px",
              padding: "36px",
              boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -2px rgba(0, 0, 0, 0.05)",
            }}
          >
            {error && (
              <div
                style={{
                  padding: "14px 16px",
                  background: "#fef2f2",
                  border: "1px solid #fecdd3",
                  borderRadius: "10px",
                  color: "#991b1b",
                  fontSize: "13px",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  marginBottom: "24px",
                }}
              >
                <AlertCircle size={18} color="#dc2626" />
                <span>{error}</span>
              </div>
            )}

            {success && (
              <div
                style={{
                  padding: "14px 16px",
                  background: "#ecfdf5",
                  border: "1px solid #a7f3d0",
                  borderRadius: "10px",
                  color: "#065f46",
                  fontSize: "13px",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  marginBottom: "24px",
                }}
              >
                <CheckCircle size={18} color="#059669" />
                <span>{success}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "28px" }}>
              {/* Row 1: Dataset Name and Observation Period */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "24px" }}>
                <div>
                  <label
                    style={{
                      display: "block",
                      fontSize: "13px",
                      fontWeight: "700",
                      color: "#0f172a",
                      marginBottom: "8px",
                    }}
                  >
                    Dataset Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={datasetName}
                    onChange={(e) => setDatasetName(e.target.value)}
                    placeholder="Weekly Demand Dataset"
                    style={{
                      width: "100%",
                      padding: "12px 14px",
                      borderRadius: "10px",
                      border: "1px solid #cbd5e1",
                      fontSize: "14px",
                      color: "#0f172a",
                      outline: "none",
                      background: "#ffffff",
                    }}
                  />
                </div>

                <div>
                  <label
                    style={{
                      display: "block",
                      fontSize: "13px",
                      fontWeight: "700",
                      color: "#0f172a",
                      marginBottom: "8px",
                    }}
                  >
                    Observation Period *
                  </label>
                  <input
                    type="text"
                    required
                    value={weekLabel}
                    onChange={(e) => setWeekLabel(e.target.value)}
                    placeholder="Oct 24 – Oct 30, 2026"
                    style={{
                      width: "100%",
                      padding: "12px 14px",
                      borderRadius: "10px",
                      border: "1px solid #cbd5e1",
                      fontSize: "14px",
                      color: "#0f172a",
                      outline: "none",
                      background: "#ffffff",
                    }}
                  />
                </div>
              </div>

              {/* Section 2: CSV Demand Data with Load Sample button */}
              <div>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    marginBottom: "12px",
                  }}
                >
                  <label style={{ fontSize: "13px", fontWeight: "700", color: "#0f172a" }}>
                    CSV Demand Data *
                  </label>

                  <button
                    type="button"
                    onClick={handleLoadSample}
                    disabled={sampleLoading}
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      gap: "8px",
                      padding: "8px 16px",
                      borderRadius: "8px",
                      border: "1px solid #fecdd3",
                      background: "#fff1f2",
                      color: "#e11d48",
                      fontSize: "12px",
                      fontWeight: "700",
                      cursor: "pointer",
                      transition: "all 0.2s",
                    }}
                  >
                    <FileSpreadsheet size={15} color="#e11d48" />
                    <span>{sampleLoading ? "Loading..." : "Load Academic Report Sample CSV"}</span>
                  </button>
                </div>

                {/* Upload Box (Dashed Container) */}
                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDragOver(true);
                  }}
                  onDragLeave={() => setIsDragOver(false)}
                  onDrop={handleDrop}
                  style={{
                    border: `2px dashed ${isDragOver ? "#e11d48" : "#e2e8f0"}`,
                    borderRadius: "14px",
                    background: isDragOver ? "#fff1f2" : "#f8fafc",
                    padding: "36px 20px",
                    textAlign: "center",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    transition: "all 0.2s ease",
                  }}
                >
                  <div
                    style={{
                      width: "48px",
                      height: "48px",
                      borderRadius: "50%",
                      background: "#ffe4e6",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      color: "#e11d48",
                      marginBottom: "14px",
                    }}
                  >
                    <UploadCloud size={24} />
                  </div>

                  <div style={{ fontSize: "14px", fontWeight: "700", color: "#0f172a", marginBottom: "4px" }}>
                    Upload your CSV file or paste content below
                  </div>
                  <div style={{ fontSize: "12px", color: "#64748b", marginBottom: "18px" }}>
                    Format: Day, Service, 9 AM–11 AM, 11 AM–1 PM, 1 PM–4 PM, 4 PM–6 PM
                  </div>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".csv,text/csv"
                    onChange={handleFileChange}
                    style={{ display: "none" }}
                  />

                  <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      style={{
                        padding: "9px 20px",
                        borderRadius: "8px",
                        background: "#e11d48",
                        color: "#ffffff",
                        fontSize: "13px",
                        fontWeight: "700",
                        border: "none",
                        cursor: "pointer",
                        transition: "background 0.2s",
                      }}
                    >
                      Choose File
                    </button>
                    <span style={{ fontSize: "12px", color: "#64748b" }}>
                      {file ? `${file.name} (${(file.size / 1024).toFixed(1)} KB)` : "No file chosen"}
                    </span>
                  </div>
                </div>

                {/* Data Preview & Integrity Verification (Replaces raw textarea) */}
                <div style={{ marginTop: "20px" }}>
                  {parsedRows.length > 0 ? (
                    <div
                      style={{
                        border: "1px solid #e2e8f0",
                        borderRadius: "12px",
                        overflow: "hidden",
                        background: "#ffffff",
                        boxShadow: "0 1px 3px rgba(0,0,0,0.05)",
                      }}
                    >
                      {/* Preview Table Header */}
                      <div
                        style={{
                          padding: "12px 18px",
                          background: "#f8fafc",
                          borderBottom: "1px solid #e2e8f0",
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                          flexWrap: "wrap",
                          gap: "10px",
                        }}
                      >
                        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                          <FileText size={16} color="#e11d48" />
                          <strong style={{ fontSize: "13px", color: "#0f172a" }}>
                            Dataset Preview &amp; Verification
                          </strong>
                          <span
                            style={{
                              fontSize: "11px",
                              fontWeight: "700",
                              background: "#ecfdf5",
                              color: "#059669",
                              padding: "2px 8px",
                              borderRadius: "9999px",
                            }}
                          >
                            ✓ {parsedRows.length} Records Verified
                          </span>
                        </div>

                        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                          <span style={{ fontSize: "11px", color: "#64748b" }}>
                            Total Weekly Demand:{" "}
                            <strong style={{ color: "#0f172a" }}>
                              {parsedRows.reduce((acc, r) => acc + r.total, 0)} orders
                            </strong>
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              setRawCsvText("");
                              setFile(null);
                            }}
                            style={{
                              display: "inline-flex",
                              alignItems: "center",
                              gap: "4px",
                              background: "transparent",
                              border: "none",
                              color: "#94a3b8",
                              fontSize: "11px",
                              cursor: "pointer",
                              padding: "4px 8px",
                            }}
                            title="Remove loaded data"
                          >
                            <X size={14} />
                            <span>Remove</span>
                          </button>
                        </div>
                      </div>

                      {/* Scrollable Preview Table */}
                      <div style={{ maxHeight: "280px", overflowY: "auto" }}>
                        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "12px" }}>
                          <thead>
                            <tr style={{ background: "#f8fafc", borderBottom: "1px solid #e2e8f0", color: "#64748b", textAlign: "left" }}>
                              <th style={{ padding: "8px 14px", fontWeight: "600" }}>Day</th>
                              <th style={{ padding: "8px 14px", fontWeight: "600" }}>Service</th>
                              <th style={{ padding: "8px 14px", fontWeight: "600", textAlign: "right" }}>9 AM – 11 AM</th>
                              <th style={{ padding: "8px 14px", fontWeight: "600", textAlign: "right" }}>11 AM – 1 PM</th>
                              <th style={{ padding: "8px 14px", fontWeight: "600", textAlign: "right" }}>1 PM – 4 PM</th>
                              <th style={{ padding: "8px 14px", fontWeight: "600", textAlign: "right" }}>4 PM – 6 PM</th>
                              <th style={{ padding: "8px 14px", fontWeight: "700", textAlign: "right", color: "#0f172a" }}>Total</th>
                            </tr>
                          </thead>
                          <tbody>
                            {parsedRows.slice(0, 8).map((row, idx) => (
                              <tr
                                key={idx}
                                style={{
                                  borderBottom: "1px solid #f1f5f9",
                                  backgroundColor: idx % 2 === 0 ? "#ffffff" : "#fbfcfe",
                                }}
                              >
                                <td style={{ padding: "8px 14px", fontWeight: "600", color: "#334155" }}>{row.day}</td>
                                <td style={{ padding: "8px 14px", color: "#475569" }}>{row.service}</td>
                                <td style={{ padding: "8px 14px", textAlign: "right", fontFamily: "var(--font-mono, monospace)" }}>{row.s1}</td>
                                <td style={{ padding: "8px 14px", textAlign: "right", fontFamily: "var(--font-mono, monospace)" }}>{row.s2}</td>
                                <td style={{ padding: "8px 14px", textAlign: "right", fontFamily: "var(--font-mono, monospace)" }}>{row.s3}</td>
                                <td style={{ padding: "8px 14px", textAlign: "right", fontFamily: "var(--font-mono, monospace)" }}>{row.s4}</td>
                                <td style={{ padding: "8px 14px", textAlign: "right", fontWeight: "700", color: "#e11d48", fontFamily: "var(--font-mono, monospace)" }}>{row.total}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>

                      {/* Footer Note */}
                      <div
                        style={{
                          padding: "8px 16px",
                          background: "#f8fafc",
                          borderTop: "1px solid #e2e8f0",
                          fontSize: "11px",
                          color: "#64748b",
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                        }}
                      >
                        <span>
                          Showing preview of first {Math.min(8, parsedRows.length)} records • Ready for full matrix rank and covariance analysis
                        </span>
                        <span style={{ color: "#059669", fontWeight: "600" }}>
                          ✓ Format Validated
                        </span>
                      </div>
                    </div>
                  ) : null}
                </div>
              </div>

              {/* Section 3: Operational Notes */}
              <div>
                <label
                  htmlFor="operational-notes"
                  style={{
                    display: "block",
                    fontSize: "15px",
                    fontWeight: "500",
                    color: "#0f172a",
                    marginBottom: "8px",
                  }}
                >
                  Operational Notes (Optional)
                </label>
                <textarea
                  id="operational-notes"
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Document any special events, equipment maintenance, or attendance deviations..."
                  style={{
                    width: "100%",
                    minHeight: "105px",
                    padding: "14px 16px",
                    borderRadius: "12px",
                    border: "1px solid #cbd5e1",
                    fontSize: "15px",
                    lineHeight: "1.5",
                    color: "#0f172a",
                    outline: "none",
                    background: "#ffffff",
                    resize: "vertical",
                    fontFamily: "inherit",
                    boxShadow: "inset 0 1px 2px rgba(0, 0, 0, 0.02)",
                    transition: "border-color 0.15s ease, box-shadow 0.15s ease",
                  }}
                  onFocus={(e) => {
                    e.currentTarget.style.borderColor = "#be123c";
                    e.currentTarget.style.boxShadow = "0 0 0 3px rgba(190, 18, 60, 0.1)";
                  }}
                  onBlur={(e) => {
                    e.currentTarget.style.borderColor = "#cbd5e1";
                    e.currentTarget.style.boxShadow = "inset 0 1px 2px rgba(0, 0, 0, 0.02)";
                  }}
                />
              </div>

              {/* Submit Button */}
              <div style={{ display: "flex", justifyContent: "flex-end", gap: "12px", paddingTop: "8px" }}>
                <button
                  type="button"
                  onClick={() => {
                    setFile(null);
                    setRawCsvText("");
                    setNotes("");
                    setError(null);
                    setSuccess(null);
                  }}
                  className="btn-secondary"
                  style={{ padding: "12px 24px", fontSize: "14px" }}
                >
                  Clear Form
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="btn-primary"
                  style={{ padding: "12px 28px", fontSize: "14px" }}
                >
                  {loading ? (
                    <>
                      <Loader2 size={16} className="animate-spin" />
                      <span>Computing Mathematical Demand Engine...</span>
                    </>
                  ) : (
                    <>
                      <span>Analyze &amp; Save Dataset</span>
                      <ArrowRight size={16} />
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </main>
    </div>
  );
}
