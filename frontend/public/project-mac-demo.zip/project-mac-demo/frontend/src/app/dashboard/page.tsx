"use client";

import { useState, useEffect } from "react";
import Sidebar from "@/components/Sidebar";
import TopHeader from "@/components/TopHeader";
import KpiCards from "@/components/KpiCards";
import DemandByServiceChart from "@/components/DemandByServiceChart";
import DemandByTimeSlotChart from "@/components/DemandByTimeSlotChart";
import WeeklyTrendChart from "@/components/WeeklyTrendChart";
import DemandMatrixTable from "@/components/DemandMatrixTable";
import ServiceBreakdownTable from "@/components/ServiceBreakdownTable";
import KeyStatisticsCard from "@/components/KeyStatisticsCard";
import InsightsRecommendations from "@/components/InsightsRecommendations";
import AdvancedAnalysisCard from "@/components/AdvancedAnalysisCard";
import OperationalCapacityCards from "@/components/OperationalCapacityCards";
import UploadModal from "@/components/UploadModal";
import { listSavedDatasets, getDatasetById } from "@/lib/api";
import { DEFAULT_BENCHMARK_CALCULATIONS as defaultCalculations } from "@/lib/constants";

export default function DashboardPage() {
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [datasetList, setDatasetList] = useState<any[]>([]);
  const [selectedDatasetId, setSelectedDatasetId] = useState<string>("");

  useEffect(() => {
    async function loadInitial() {
      setLoading(true);
      try {
        const datasets = await listSavedDatasets();
        setDatasetList(datasets);
        if (datasets.length > 0) {
          const latest = datasets[0];
          setSelectedDatasetId(latest.id);
          const details = await getDatasetById(latest.id);
          if (details && details.calculations) {
            setDashboardData(details.calculations);
          } else {
            setDashboardData(defaultCalculations);
          }
        } else {
          setDashboardData(defaultCalculations);
        }
      } catch (err) {
        console.error("Failed to load initial dataset from Supabase:", err);
        setDashboardData(defaultCalculations);
      } finally {
        setLoading(false);
      }
    }
    loadInitial();
  }, []);

  const handleSelectDataset = async (id: string) => {
    setSelectedDatasetId(id);
    if (!id) {
      setDashboardData(defaultCalculations);
      return;
    }
    try {
      setLoading(true);
      const details = await getDatasetById(id);
      if (details && details.calculations) {
        setDashboardData(details.calculations);
      }
    } catch (err) {
      console.error("Error loading dataset:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleUploadSuccess = (uploadRes: any) => {
    if (uploadRes && uploadRes.calculations) {
      setDashboardData(uploadRes.calculations);
      if (uploadRes.dataset_id) {
        setSelectedDatasetId(uploadRes.dataset_id);
      }
      // Refresh list
      listSavedDatasets().then(setDatasetList).catch(console.error);
    }
  };

  const normalize = (raw: any) => {
    if (!raw) return defaultCalculations;
    const total =
      raw.total_weekly_demand ??
      (raw.service_totals
        ? Object.values(raw.service_totals).reduce((a: any, b: any) => a + Number(b), 0)
        : defaultCalculations.total_weekly_demand);
    const avgDaily =
      raw.average_daily_demand ??
      (total ? Number((total / 7).toFixed(2)) : defaultCalculations.average_daily_demand);

    let topService = raw.top_service;
    if (!topService && raw.service_totals) {
      const sorted = Object.entries(raw.service_totals).sort(
        (a: any, b: any) => (b[1] as number) - (a[1] as number)
      );
      if (sorted.length > 0) {
        topService = {
          name: sorted[0][0],
          total_demand: sorted[0][1],
          percentage: total ? Number((((sorted[0][1] as number) / total) * 100).toFixed(2)) : 0,
        };
      }
    }

    let peakSlot = raw.peak_time_slot;
    if (!peakSlot && raw.timeslot_totals) {
      const sorted = Object.entries(raw.timeslot_totals).sort(
        (a: any, b: any) => (b[1] as number) - (a[1] as number)
      );
      if (sorted.length > 0) {
        peakSlot = {
          label: sorted[0][0],
          total_demand: sorted[0][1],
          rate_per_hour: raw.duration_adjusted_rates?.[sorted[0][0]] ?? 0,
        };
      }
    }

    let advanced = raw.advanced_analysis;
    if (!advanced) {
      advanced = {
        matrix_rank: raw.matrix_rank ?? 7,
        mean_vector: raw.mean_vector ?? defaultCalculations.advanced_analysis.mean_vector,
        covariance_matrix: raw.covariance_matrix ?? defaultCalculations.advanced_analysis.covariance_matrix,
        correlation_matrix: raw.correlation_matrix ?? defaultCalculations.advanced_analysis.correlation_matrix,
        eigenvalues: raw.eigenvalues ?? defaultCalculations.advanced_analysis.eigenvalues,
        eigenvectors: raw.eigenvectors ?? defaultCalculations.advanced_analysis.eigenvectors,
        variance_explained: raw.variance_explained ?? defaultCalculations.advanced_analysis.variance_explained,
        dominant_direction: raw.dominant_direction ?? defaultCalculations.advanced_analysis.dominant_direction,
      };
    }

    return {
      ...defaultCalculations,
      ...raw,
      total_weekly_demand: total,
      average_daily_demand: avgDaily,
      top_service: topService ?? defaultCalculations.top_service,
      peak_time_slot: peakSlot ?? defaultCalculations.peak_time_slot,
      advanced_analysis: advanced,
    };
  };

  const calc = normalize(dashboardData);

  return (
    <div className="app-container">
      {/* Sidebar Navigation */}
      <Sidebar onOpenUpload={() => setIsUploadOpen(true)} />

      {/* Main Page Area */}
      <main className="main-wrapper">
        <TopHeader onOpenUpload={() => setIsUploadOpen(true)} />

        <div className="dashboard-content animate-fade-in">
          {/* Dataset Switcher Bar if datasets exist */}
          {datasetList.length > 0 && (
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                background: "#ffffff",
                padding: "10px 18px",
                borderRadius: "10px",
                border: "1px solid #e2e8f0",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <span style={{ fontSize: "12px", fontWeight: "700", color: "#64748b" }}>
                  Selected Dataset:
                </span>
                <select
                  value={selectedDatasetId}
                  onChange={(e) => handleSelectDataset(e.target.value)}
                  style={{
                    padding: "6px 12px",
                    borderRadius: "6px",
                    border: "1px solid #cbd5e1",
                    fontSize: "13px",
                    fontWeight: "600",
                    color: "#0f172a",
                    background: "#f8fafc",
                    outline: "none",
                  }}
                >
                  <option value="">Academic Benchmark Dataset (Default)</option>
                  {datasetList.map((ds) => (
                    <option key={ds.id} value={ds.id}>
                      {ds.dataset_name} ({ds.week_label || "Week"}) — {ds.total_demand} orders
                    </option>
                  ))}
                </select>
              </div>

              <span style={{ fontSize: "11px", color: "#059669", fontWeight: "600" }}>
                ✓ Persisted in Supabase PostgreSQL
              </span>
            </div>
          )}

          {/* Row 1: KPI Stats Cards */}
          <KpiCards
            totalDemand={calc.total_weekly_demand}
            averageDailyDemand={calc.average_daily_demand}
            peakTimeSlot={calc.peak_time_slot}
            topService={calc.top_service}
          />

          {/* Row 2: 3 Visual Charts */}
          <div className="charts-grid-3">
            <DemandByServiceChart
              totalDemand={calc.total_weekly_demand}
              serviceTotals={calc.service_totals}
              servicePercentages={calc.service_percentages}
            />
            <DemandByTimeSlotChart
              timeslotTotals={calc.timeslot_totals}
              durationAdjustedRates={calc.duration_adjusted_rates}
            />
            <WeeklyTrendChart dailyTotals={calc.daily_totals || []} />
          </div>

          {/* Row 3: Tables & Key Statistics */}
          <div className="tables-grid-3">
            <DemandMatrixTable
              weeklyMatrix={calc.weekly_matrix}
              timeslotTotals={calc.timeslot_totals}
            />
            <ServiceBreakdownTable
              totalDemand={calc.total_weekly_demand}
              serviceTotals={calc.service_totals}
              servicePercentages={calc.service_percentages}
            />
            <KeyStatisticsCard
              peakSlot={calc.peak_time_slot}
              topService={calc.top_service}
              leastSlot={{ label: "4 PM – 6 PM", total_demand: calc.timeslot_totals?.["4 PM–6 PM"] || 180 }}
              estimatedPages={
                calc.printer_metrics?.hp_laser_303dw?.estimated_pages +
                calc.printer_metrics?.canon_pixma_g670?.estimated_pages
              }
            />
          </div>

          {/* Row 4: Operational Equipment & Staff Workload */}
          <OperationalCapacityCards
            printerMetrics={calc.printer_metrics}
            staffMetrics={calc.staff_metrics}
          />

          {/* Row 5: Insights & Advanced Mathematical Analysis */}
          <div className="bottom-grid-2">
            <InsightsRecommendations recommendations={calc.recommendations || []} />
            <AdvancedAnalysisCard
              covarianceMatrix={calc.advanced_analysis?.covariance_matrix}
              correlationMatrix={calc.advanced_analysis?.correlation_matrix}
              eigenvalues={calc.advanced_analysis?.eigenvalues}
              varianceExplained={calc.advanced_analysis?.variance_explained}
              matrixRank={calc.advanced_analysis?.matrix_rank}
            />
          </div>

          {/* Dashboard Footer */}
          <footer
            style={{
              marginTop: "20px",
              paddingTop: "16px",
              borderTop: "1px solid #e2e8f0",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              fontSize: "12px",
              color: "#94a3b8",
            }}
          >
            <span>BQ PRINTERS | Demand Analyzer v1.0</span>
            <span>Built for smarter printing businesses ❤️</span>
          </footer>
        </div>
      </main>

      {/* Upload CSV Modal */}
      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onSuccess={handleUploadSuccess}
      />
    </div>
  );
}
