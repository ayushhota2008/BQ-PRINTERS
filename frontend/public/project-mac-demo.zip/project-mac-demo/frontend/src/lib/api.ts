import { supabase } from "@/lib/supabase";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api";

async function getAuthToken(): Promise<string | undefined> {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    return session?.access_token;
  } catch {
    return undefined;
  }
}

export async function fetchHealth() {
  const res = await fetch(`${API_BASE}/health`);
  return res.json();
}

export async function fetchSampleCsv(): Promise<string> {
  const res = await fetch(`${API_BASE}/sample-dataset?format=csv`);
  const data = await res.json();
  return data.csv;
}

export async function analyzeCsvFile(
  file: File,
  datasetName?: string,
  weekLabel?: string,
  saveToSupabase: boolean = true,
  assumptions?: any,
  token?: string,
  notes?: string
) {
  const formData = new FormData();
  formData.append("file", file);
  if (datasetName) formData.append("dataset_name", datasetName);
  if (weekLabel) formData.append("week_label", weekLabel);
  const notesVal = notes || assumptions?.notes || assumptions?.operational_notes;
  if (notesVal) formData.append("notes", notesVal);
  formData.append("save_to_supabase", saveToSupabase ? "true" : "false");
  if (assumptions) {
    formData.append("assumptions_json", JSON.stringify(assumptions));
  }

  const authToken = token || (await getAuthToken());
  const headers: Record<string, string> = {};
  if (authToken) {
    headers["Authorization"] = `Bearer ${authToken}`;
  }

  const res = await fetch(`${API_BASE}/analyze-csv`, {
    method: "POST",
    headers,
    body: formData,
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: "Upload failed" }));
    throw new Error(err.detail || "Validation or calculation error");
  }

  return res.json();
}

export async function listSavedDatasets(token?: string) {
  const authToken = token || (await getAuthToken());
  const headers: Record<string, string> = {};
  if (authToken) {
    headers["Authorization"] = `Bearer ${authToken}`;
  }
  const res = await fetch(`${API_BASE}/datasets`, { headers });
  if (!res.ok) return [];
  return res.json();
}

export async function getDatasetById(datasetId: string) {
  const res = await fetch(`${API_BASE}/datasets/${datasetId}`);
  if (!res.ok) throw new Error("Dataset not found");
  return res.json();
}

export async function deleteDatasetById(datasetId: string) {
  const authToken = await getAuthToken();
  const headers: Record<string, string> = {};
  if (authToken) {
    headers["Authorization"] = `Bearer ${authToken}`;
  }
  const res = await fetch(`${API_BASE}/datasets/${datasetId}`, {
    method: "DELETE",
    headers,
  });
  if (!res.ok) throw new Error("Failed to delete dataset");
  return res.json();
}

export async function compareMultipleWeeks(datasetIds: string[]) {
  const res = await fetch(`${API_BASE}/compare-weeks`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(datasetIds),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: "Comparison failed" }));
    throw new Error(err.detail || "Failed to compare weeks");
  }
  return res.json();
}
