"use client";

import { useState, useEffect, useRef } from "react";
import { Calendar, Sun, Moon, Monitor, X, Lock, CheckCircle2, AlertCircle } from "lucide-react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

interface TopHeaderProps {
  lastUpdated?: string;
  onOpenUpload?: () => void;
  shopkeeperName?: string;
}

export default function TopHeader({
  lastUpdated = "Today",
  onOpenUpload,
  shopkeeperName = "N",
}: TopHeaderProps) {
  const router = useRouter();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [theme, setTheme] = useState<"light" | "dark" | "system">("light");
  const [currentUser, setCurrentUser] = useState<{
    name: string;
    email: string;
    role: string;
    avatar?: string | null;
  }>({
    name: "newmem821",
    email: "newmem821@gmail.com",
    role: "Admin",
    avatar: null,
  });

  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [passwordMessage, setPasswordMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  const dropdownRef = useRef<HTMLDivElement>(null);

  // Check Supabase session
  useEffect(() => {
    async function loadUser() {
      try {
        const { data } = await supabase.auth.getUser();
        if (data?.user?.email) {
          const email = data.user.email;
          const name =
            data.user.user_metadata?.full_name ||
            data.user.user_metadata?.name ||
            email.split("@")[0] ||
            "Shopkeeper";
          const role = data.user.user_metadata?.role || "Shop Owner / Admin";
          const avatar =
            data.user.user_metadata?.avatar_url ||
            data.user.user_metadata?.picture ||
            null;
          setCurrentUser({ name, email, role, avatar });
        }
      } catch {
        // Fallback to default
      }
    }
    loadUser();
  }, []);

  // Handle click outside to close dropdown
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    }

    if (isDropdownOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isDropdownOpen]);

  const handleSignOut = async () => {
    setIsDropdownOpen(false);
    try {
      await supabase.auth.signOut();
    } catch (err) {
      console.error("Sign out error:", err);
    }
    router.push("/login");
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 6) {
      setPasswordMessage({ type: "error", text: "Password must be at least 6 characters long." });
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordMessage({ type: "error", text: "Passwords do not match." });
      return;
    }

    setPasswordLoading(true);
    setPasswordMessage(null);
    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;
      setPasswordMessage({ type: "success", text: "Password updated successfully!" });
      setTimeout(() => {
        setIsPasswordModalOpen(false);
        setNewPassword("");
        setConfirmPassword("");
        setPasswordMessage(null);
      }, 1400);
    } catch (err: any) {
      setPasswordMessage({ type: "error", text: err.message || "Failed to update password." });
    } finally {
      setPasswordLoading(false);
    }
  };

  return (
    <>
      <header
        className="top-header"
        style={{
          padding: "20px 32px",
          borderBottom: "1px solid #e2e8f0",
          background: "#ffffff",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          position: "relative",
        }}
      >
        <div className="header-title">
          <h1 style={{ fontSize: "20px", fontWeight: "800", color: "#0f172a", letterSpacing: "-0.4px" }}>
            Demand Analyzer Dashboard
          </h1>
          <p style={{ fontSize: "13px", color: "#64748b", marginTop: "2px" }}>
            Turn your printing data into clear insights and better decisions.
          </p>
        </div>

        <div className="header-actions" style={{ display: "flex", alignItems: "center", gap: "14px" }}>
          <div
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "8px",
              background: "#f1f5f9",
              padding: "8px 16px",
              borderRadius: "8px",
              fontSize: "12px",
              color: "#475569",
              fontWeight: "500",
            }}
          >
            <Calendar size={14} color="#e11d48" />
            <span>
              Last Updated: <strong style={{ color: "#0f172a" }}>{lastUpdated}</strong>
            </span>
          </div>

          {/* Profile Dropdown Container */}
          <div ref={dropdownRef} style={{ position: "relative" }}>
            <button
              type="button"
              id="profile-dropdown-button"
              onClick={() => setIsDropdownOpen((prev) => !prev)}
              aria-expanded={isDropdownOpen}
              style={{
                width: "38px",
                height: "38px",
                borderRadius: "50%",
                background: currentUser.avatar ? "transparent" : "#be123c",
                color: "#ffffff",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontWeight: "700",
                fontSize: "15px",
                border: currentUser.avatar ? "2px solid #e2e8f0" : "none",
                cursor: "pointer",
                boxShadow: "0 2px 4px rgba(190, 18, 60, 0.2)",
                outline: "none",
                transition: "transform 0.15s ease",
                overflow: "hidden",
                padding: 0,
              }}
              title="Account Menu"
            >
              {currentUser.avatar ? (
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  style={{ width: "100%", height: "100%", objectFit: "cover" }}
                />
              ) : (
                (currentUser.name?.[0] || shopkeeperName?.[0] || "N").toUpperCase()
              )}
            </button>

            {/* Profile Dropdown Menu */}
            {isDropdownOpen && (
              <div
                id="profile-dropdown-menu"
                style={{
                  position: "absolute",
                  top: "calc(100% + 8px)",
                  right: 0,
                  width: "270px",
                  background: "#ffffff",
                  border: "1px solid #e2e8f0",
                  borderRadius: "12px",
                  boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.04)",
                  zIndex: 1000,
                  overflow: "hidden",
                  textAlign: "left",
                  animation: "fadeIn 0.15s ease-out",
                }}
              >
                {/* User Info Header */}
                <div style={{ padding: "16px 18px", display: "flex", gap: "12px", alignItems: "center" }}>
                  {currentUser.avatar && (
                    <img
                      src={currentUser.avatar}
                      alt={currentUser.name}
                      style={{
                        width: "42px",
                        height: "42px",
                        borderRadius: "50%",
                        objectFit: "cover",
                        border: "1px solid #e2e8f0",
                        flexShrink: 0,
                      }}
                    />
                  )}
                  <div style={{ overflow: "hidden", flex: 1 }}>
                    <div style={{ fontSize: "15px", fontWeight: "600", color: "#0f172a", lineHeight: 1.25, textOverflow: "ellipsis", overflow: "hidden", whiteSpace: "nowrap" }}>
                      {currentUser.name}
                    </div>
                    <div style={{ fontSize: "13px", color: "#64748b", marginTop: "3px", lineHeight: 1.25, textOverflow: "ellipsis", overflow: "hidden", whiteSpace: "nowrap" }}>
                      {currentUser.email}
                    </div>
                    <div style={{ fontSize: "12px", color: "#e11d48", fontWeight: "600", marginTop: "3px", lineHeight: 1.25 }}>
                      {currentUser.role}
                    </div>
                  </div>
                </div>

                {/* Divider */}
                <div style={{ height: "1px", background: "#f1f5f9" }} />

                {/* Theme Selector Section */}
                <div style={{ padding: "14px 18px 16px 18px" }}>
                  <div style={{ fontSize: "14px", color: "#64748b", marginBottom: "10px", fontWeight: "400" }}>
                    Theme
                  </div>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      border: "1px solid #cbd5e1",
                      borderRadius: "12px",
                      padding: "4px",
                      background: "#ffffff",
                      gap: "4px",
                    }}
                  >
                    <button
                      type="button"
                      id="theme-light-btn"
                      onClick={() => setTheme("light")}
                      style={{
                        flex: 1,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        height: "36px",
                        border: "none",
                        borderRadius: "8px",
                        background: theme === "light" ? "#e8edf2" : "transparent",
                        cursor: "pointer",
                        transition: "all 0.15s ease",
                      }}
                      title="Light Theme"
                    >
                      <Sun size={18} color="#0f172a" strokeWidth={1.75} />
                    </button>
                    <button
                      type="button"
                      id="theme-dark-btn"
                      onClick={() => setTheme("dark")}
                      style={{
                        flex: 1,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        height: "36px",
                        border: "none",
                        borderRadius: "8px",
                        background: theme === "dark" ? "#e8edf2" : "transparent",
                        cursor: "pointer",
                        transition: "all 0.15s ease",
                      }}
                      title="Dark Theme"
                    >
                      <Moon size={18} color="#0f172a" strokeWidth={1.75} />
                    </button>
                    <button
                      type="button"
                      id="theme-system-btn"
                      onClick={() => setTheme("system")}
                      style={{
                        flex: 1,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        height: "36px",
                        border: "none",
                        borderRadius: "8px",
                        background: theme === "system" ? "#e8edf2" : "transparent",
                        cursor: "pointer",
                        transition: "all 0.15s ease",
                      }}
                      title="System Theme"
                    >
                      <Monitor size={18} color="#0f172a" strokeWidth={1.75} />
                    </button>
                  </div>
                </div>

                {/* Divider */}
                <div style={{ height: "1px", background: "#f1f5f9" }} />

                {/* Change Password */}
                <button
                  type="button"
                  id="change-password-menu-item"
                  onClick={() => {
                    setIsDropdownOpen(false);
                    setIsPasswordModalOpen(true);
                  }}
                  style={{
                    display: "block",
                    width: "100%",
                    padding: "14px 18px",
                    textAlign: "left",
                    background: "transparent",
                    border: "none",
                    fontSize: "15px",
                    color: "#0f172a",
                    fontWeight: "400",
                    cursor: "pointer",
                    transition: "background 0.15s ease",
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = "#f8fafc")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                >
                  Change password
                </button>

                {/* Divider */}
                <div style={{ height: "1px", background: "#f1f5f9" }} />

                {/* Sign Out */}
                <button
                  type="button"
                  id="sign-out-menu-item"
                  onClick={handleSignOut}
                  style={{
                    display: "block",
                    width: "100%",
                    padding: "14px 18px",
                    textAlign: "left",
                    background: "transparent",
                    border: "none",
                    fontSize: "15px",
                    color: "#0f172a",
                    fontWeight: "400",
                    cursor: "pointer",
                    transition: "background 0.15s ease",
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = "#f8fafc")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                >
                  Sign out
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Change Password Modal */}
      {isPasswordModalOpen && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15, 23, 42, 0.45)",
            backdropFilter: "blur(4px)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 9999,
            padding: "20px",
          }}
        >
          <div
            style={{
              background: "#ffffff",
              borderRadius: "16px",
              padding: "28px",
              width: "100%",
              maxWidth: "420px",
              boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.05)",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <div
                  style={{
                    width: "36px",
                    height: "36px",
                    borderRadius: "10px",
                    background: "#fef2f2",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Lock size={18} color="#be123c" />
                </div>
                <div>
                  <h3 style={{ fontSize: "17px", fontWeight: "700", color: "#0f172a" }}>Change Password</h3>
                  <p style={{ fontSize: "12px", color: "#64748b" }}>Update your account password</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsPasswordModalOpen(false)}
                style={{
                  border: "none",
                  background: "#f1f5f9",
                  borderRadius: "8px",
                  padding: "6px",
                  cursor: "pointer",
                  display: "flex",
                }}
              >
                <X size={16} color="#64748b" />
              </button>
            </div>

            {passwordMessage && (
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  padding: "10px 14px",
                  borderRadius: "8px",
                  marginBottom: "16px",
                  fontSize: "13px",
                  background: passwordMessage.type === "success" ? "#ecfdf5" : "#fef2f2",
                  color: passwordMessage.type === "success" ? "#065f46" : "#991b1b",
                  border: `1px solid ${passwordMessage.type === "success" ? "#a7f3d0" : "#fecaca"}`,
                }}
              >
                {passwordMessage.type === "success" ? (
                  <CheckCircle2 size={16} color="#10b981" />
                ) : (
                  <AlertCircle size={16} color="#ef4444" />
                )}
                <span>{passwordMessage.text}</span>
              </div>
            )}

            <form onSubmit={handleChangePassword}>
              <div style={{ marginBottom: "16px" }}>
                <label style={{ display: "block", fontSize: "13px", fontWeight: "600", color: "#334155", marginBottom: "6px" }}>
                  New Password
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Enter new password (min. 6 characters)"
                  required
                  style={{
                    width: "100%",
                    padding: "10px 14px",
                    borderRadius: "8px",
                    border: "1px solid #cbd5e1",
                    fontSize: "14px",
                    outline: "none",
                  }}
                />
              </div>

              <div style={{ marginBottom: "22px" }}>
                <label style={{ display: "block", fontSize: "13px", fontWeight: "600", color: "#334155", marginBottom: "6px" }}>
                  Confirm New Password
                </label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm new password"
                  required
                  style={{
                    width: "100%",
                    padding: "10px 14px",
                    borderRadius: "8px",
                    border: "1px solid #cbd5e1",
                    fontSize: "14px",
                    outline: "none",
                  }}
                />
              </div>

              <div style={{ display: "flex", gap: "10px", justifyContent: "flex-end" }}>
                <button
                  type="button"
                  onClick={() => setIsPasswordModalOpen(false)}
                  style={{
                    padding: "10px 18px",
                    borderRadius: "8px",
                    border: "1px solid #cbd5e1",
                    background: "#ffffff",
                    fontSize: "13px",
                    fontWeight: "600",
                    color: "#475569",
                    cursor: "pointer",
                  }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={passwordLoading}
                  style={{
                    padding: "10px 20px",
                    borderRadius: "8px",
                    border: "none",
                    background: "#be123c",
                    fontSize: "13px",
                    fontWeight: "600",
                    color: "#ffffff",
                    cursor: passwordLoading ? "not-allowed" : "pointer",
                    opacity: passwordLoading ? 0.7 : 1,
                  }}
                >
                  {passwordLoading ? "Updating..." : "Update Password"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
