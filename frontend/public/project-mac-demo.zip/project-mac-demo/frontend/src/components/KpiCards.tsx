"use client";

import { BarChart2, Calendar, Clock, Printer, ArrowUpRight } from "lucide-react";
import { formatInteger } from "@/lib/format";

interface KpiCardsProps {
  totalDemand: number;
  averageDailyDemand: number;
  peakTimeSlot: {
    label: string;
    total_demand: number;
    rate_per_hour?: number;
  };
  topService: {
    name: string;
    total_demand: number;
    percentage: number;
  };
}

export default function KpiCards({
  totalDemand,
  averageDailyDemand,
  peakTimeSlot,
  topService,
}: KpiCardsProps) {
  return (
    <div className="kpi-grid">
      {/* 1. Total Demand */}
      <div className="kpi-card">
        <div className="kpi-card-top">
          <span className="kpi-label">Total Demand (Weekly)</span>
          <div className="kpi-icon-wrapper">
            <BarChart2 size={20} />
          </div>
        </div>
        <div>
          <div className="kpi-value">{formatInteger(totalDemand)}</div>
          <div style={{ marginTop: "6px" }}>
            <span className="badge-growth">
              <ArrowUpRight size={12} />
              12% vs. previous week
            </span>
          </div>
        </div>
      </div>

      {/* 2. Average Daily Demand */}
      <div className="kpi-card">
        <div className="kpi-card-top">
          <span className="kpi-label">Average Daily Demand</span>
          <div className="kpi-icon-wrapper">
            <Calendar size={20} />
          </div>
        </div>
        <div>
          <div className="kpi-value">
            {typeof averageDailyDemand === "number"
              ? averageDailyDemand.toFixed(2)
              : totalDemand
              ? (totalDemand / 7).toFixed(2)
              : "0.00"}
          </div>
          <div style={{ marginTop: "6px" }}>
            <span className="badge-growth">
              <ArrowUpRight size={12} />
              12% vs. previous week
            </span>
          </div>
        </div>
      </div>

      {/* 3. Peak Time Slot */}
      <div className="kpi-card">
        <div className="kpi-card-top">
          <span className="kpi-label">Peak Time Slot</span>
          <div className="kpi-icon-wrapper">
            <Clock size={20} />
          </div>
        </div>
        <div>
          <div className="kpi-value" style={{ fontSize: "22px" }}>
            {peakTimeSlot?.label || "11 AM – 1 PM"}
          </div>
          <div className="kpi-subtext" style={{ marginTop: "6px" }}>
            ({peakTimeSlot?.total_demand ?? 0} requests)
          </div>
        </div>
      </div>

      {/* 4. Top Service */}
      <div className="kpi-card">
        <div className="kpi-card-top">
          <span className="kpi-label">Top Service</span>
          <div className="kpi-icon-wrapper">
            <Printer size={20} />
          </div>
        </div>
        <div>
          <div className="kpi-value" style={{ fontSize: "22px" }}>
            {topService?.name || "B&W Printing"}
          </div>
          <div className="kpi-subtext" style={{ marginTop: "6px" }}>
            {typeof topService?.percentage === "number"
              ? topService.percentage.toFixed(2)
              : "0.00"}
            % of total demand
          </div>
        </div>
      </div>
    </div>
  );
}
