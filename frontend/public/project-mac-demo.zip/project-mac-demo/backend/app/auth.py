import jwt
import logging
from typing import Optional, Dict, Any
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from app.config import settings
from app.supabase_client import supabase_service

logger = logging.getLogger(__name__)
security = HTTPBearer(auto_error=False)

def get_current_user_optional(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)
) -> Optional[Dict[str, Any]]:
    """
    Optional authentication for endpoints that support both public/guest mode
    and authenticated shopkeeper profiles.
    """
    if not credentials:
        return None

    token = credentials.credentials
    try:
        # If Supabase client is available, verify token via Supabase Auth API
        if supabase_service.client:
            try:
                user_resp = supabase_service.client.auth.get_user(token)
                if user_resp and user_resp.user:
                    return {
                        "id": user_resp.user.id,
                        "email": user_resp.user.email,
                        "role": user_resp.user.role
                    }
            except Exception as e:
                logger.warning(f"Supabase auth verification failed, falling back to JWT decode: {e}")

        # Fallback: verify signature only if secret is configured
        if settings.SUPABASE_JWT_SECRET:
            payload = jwt.decode(
                token,
                key=settings.SUPABASE_JWT_SECRET,
                algorithms=["HS256"],
                options={"verify_signature": True}
            )
            return {
                "id": payload.get("sub"),
                "email": payload.get("email"),
                "role": payload.get("role")
            }
        return None
    except Exception as e:
        logger.error(f"Invalid authentication token: {e}")
        return None

def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)
) -> Dict[str, Any]:
    """
    Strict authentication requiring a valid Supabase JWT.
    """
    user = get_current_user_optional(credentials)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Valid Supabase authentication token required.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user
