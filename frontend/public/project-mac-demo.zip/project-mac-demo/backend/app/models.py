from typing import List, Dict, Optional, Any
from pydantic import BaseModel, Field
from datetime import datetime

class DailyObservationInput(BaseModel):
    day_number: int = Field(..., ge=1, le=7)
    day_name: str
    service: str
    slot_9_11: int = Field(..., ge=0)
    slot_11_1: int = Field(..., ge=0)
    slot_1_4: int = Field(..., ge=0)
    slot_4_6: int = Field(..., ge=0)

class DatasetAssumptions(BaseModel):
    staff_count: int = Field(default=3, ge=1)
    daily_operating_hours: float = Field(default=9.0, ge=1.0)
    hp_rated_ppm: float = Field(default=30.0, ge=1.0)
    canon_rated_ipm: float = Field(default=3.9, ge=0.5)
    pages_per_order: Dict[str, int] = Field(default_factory=lambda: {
        "bw": 4,
        "colour": 3,
        "photocopying": 5,
        "binding": 0
    })
    handling_time_min: Dict[str, float] = Field(default_factory=lambda: {
        "bw": 2.0,
        "colour": 4.0,
        "binding": 8.0,
        "photocopying": 2.0
    })
    daily_schedule: List[Dict[str, Any]] = Field(default_factory=list)
    notes: Optional[str] = None
    operational_notes: Optional[str] = None

class PrinterMetrics(BaseModel):
    hp_laser_303dw: Dict[str, Any]
    canon_pixma_g670: Dict[str, Any]
    photocopying_standalone: Optional[Dict[str, Any]] = None
    assumptions: Dict[str, Any]

class StaffMetrics(BaseModel):
    scheduled_availability_weekly_hours: float
    actual_available_weekly_hours: float
    total_workload_minutes: float
    total_workload_hours: float
    weekly_utilization_percent: float
    daily_breakdown: List[Dict[str, Any]]
    assumptions: Dict[str, Any]

class AdvancedAnalysisResult(BaseModel):
    matrix_rank: int
    mean_vector: Dict[str, float]
    covariance_matrix: Dict[str, Dict[str, float]]
    correlation_matrix: Dict[str, Dict[str, float]]
    eigenvalues: List[float]
    variance_explained: List[float]
    eigenvectors: List[List[float]]
    dominant_direction: str

class BusinessRecommendation(BaseModel):
    id: int
    title: str
    description: str
    category: str
    priority: str

class CalculationResult(BaseModel):
    total_weekly_demand: int
    average_daily_demand: float
    top_service: Dict[str, Any]
    peak_time_slot: Dict[str, Any]
    weekly_matrix: List[List[int]]
    average_daily_matrix: List[List[float]]
    service_totals: Dict[str, int]
    service_percentages: Dict[str, float]
    timeslot_totals: Dict[str, int]
    duration_adjusted_rates: Dict[str, float]
    daily_totals: List[Dict[str, Any]]
    busiest_day: Dict[str, Any]
    least_busy_day: Dict[str, Any]
    printer_metrics: PrinterMetrics
    staff_metrics: StaffMetrics
    advanced_analysis: AdvancedAnalysisResult
    recommendations: List[BusinessRecommendation]

class DatasetResponse(BaseModel):
    id: str
    dataset_name: str
    week_label: Optional[str] = None
    created_at: str
    total_demand: int
    calculations: CalculationResult
    assumptions: DatasetAssumptions

class WeekComparisonItem(BaseModel):
    dataset_id: str
    dataset_name: str
    week_label: Optional[str] = None
    total_demand: int
    average_daily_demand: float
    peak_time_slot: str
    top_service: str
    busiest_day: str
    hp_load_ratio: float
    canon_load_ratio: float
    staff_utilization: float

class WeekComparisonResponse(BaseModel):
    datasets: List[WeekComparisonItem]
    absolute_differences: Dict[str, Any]
    percentage_differences: Dict[str, Any]
    summary_insights: List[str]
