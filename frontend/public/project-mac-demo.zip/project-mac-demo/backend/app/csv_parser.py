import csv
import io
import re
from typing import List, Tuple, Dict, Any
import numpy as np

REQUIRED_SERVICES = [
    "B&W Printing",
    "Colour Printing",
    "Binding",
    "Photocopying"
]

DEFAULT_WEEKDAYS = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday"
]

def normalize_service_name(name: str) -> str:
    cleaned = re.sub(r'[^a-zA-Z]', '', str(name)).lower()
    if "bw" in cleaned or "black" in cleaned or "b&w" in str(name).lower():
        return "B&W Printing"
    elif "col" in cleaned:
        return "Colour Printing"
    elif "bind" in cleaned:
        return "Binding"
    elif "photo" in cleaned or "copy" in cleaned or "xerox" in cleaned:
        return "Photocopying"
    return str(name).strip()

def normalize_column_name(col: str) -> str:
    cleaned = re.sub(r'\s+', ' ', str(col).strip())
    c_lower = cleaned.lower()
    if "day" in c_lower:
        return "Day"
    elif "serv" in c_lower:
        return "Service"
    elif "9" in c_lower and "11" in c_lower:
        return "9 AM–11 AM"
    elif "11" in c_lower and "1" in c_lower:
        return "11 AM–1 PM"
    elif "1" in c_lower and "4" in c_lower:
        return "1 PM–4 PM"
    elif "4" in c_lower and "6" in c_lower:
        return "4 PM–6 PM"
    return cleaned

class CSVParser:
    @staticmethod
    def parse_and_validate(csv_content: str) -> Tuple[List[np.ndarray], List[str], np.ndarray, List[Dict[str, Any]]]:
        """
        Parses CSV data, validates integrity, columns, ranges, and structures it into:
        - daily_matrices: 7 numpy arrays of shape (4, 4)
        - day_names: 7 string labels
        - observations: (28, 4) numpy array of service counts per slot
        - structured_rows: list of dictionaries for database storage

        Auto-fills omitted services with 0 demand and auto-pads weeks with < 7 days
        so partial records are accepted without breaking the 4x4 weekly matrix model.
        """
        if not csv_content or not csv_content.strip():
            raise ValueError("The uploaded CSV file is empty.")

        try:
            reader = list(csv.reader(io.StringIO(csv_content.strip())))
        except Exception as e:
            raise ValueError(f"Unable to read CSV file: {str(e)}")

        if not reader:
            raise ValueError("The uploaded CSV file is empty.")

        raw_header = reader[0]
        col_indices = {normalize_column_name(c): idx for idx, c in enumerate(raw_header)}

        required_cols = ["Day", "Service", "9 AM–11 AM", "11 AM–1 PM", "1 PM–4 PM", "4 PM–6 PM"]
        missing_cols = [c for c in required_cols if c not in col_indices]
        if missing_cols:
            raise ValueError(f"Missing required columns in CSV: {', '.join(missing_cols)}. Expected: {', '.join(required_cols)}")

        time_cols = ["9 AM–11 AM", "11 AM–1 PM", "1 PM–4 PM", "4 PM–6 PM"]
        time_col_idxs = [col_indices[tc] for tc in time_cols]
        day_idx = col_indices["Day"]
        service_idx = col_indices["Service"]

        # Parse rows and group by day while maintaining order
        days_order = []
        day_records: Dict[str, Dict[str, List[int]]] = {}

        for row_num, row in enumerate(reader[1:], start=2):
            if not row or not any(field.strip() for field in row):
                continue

            day_name = row[day_idx].strip() if day_idx < len(row) else ""
            if not day_name:
                continue

            raw_serv = row[service_idx] if service_idx < len(row) else ""
            service = normalize_service_name(raw_serv)

            # Validate numeric counts
            counts = []
            for col_name, c_idx in zip(time_cols, time_col_idxs):
                val_str = row[c_idx].strip() if c_idx < len(row) else ""
                try:
                    val = int(float(val_str)) if val_str else 0
                except (ValueError, TypeError):
                    raise ValueError(f"Column '{col_name}' contains non-numeric value at row {row_num}.")
                if val < 0:
                    raise ValueError(f"Column '{col_name}' contains negative value at row {row_num}.")
                counts.append(val)

            if day_name not in day_records:
                days_order.append(day_name)
                day_records[day_name] = {}

            # If duplicate service entry exists for the same day, accumulate counts
            if service in day_records[day_name]:
                day_records[day_name][service] = [
                    a + b for a, b in zip(day_records[day_name][service], counts)
                ]
            else:
                day_records[day_name][service] = counts

        if not days_order:
            raise ValueError("The uploaded CSV contains no valid daily demand records.")

        # Ensure exactly 7 days: slice if > 7, pad with zero-demand if < 7
        if len(days_order) > 7:
            days_order = days_order[:7]
        elif len(days_order) < 7:
            # Check if user used standard weekday names
            known_weekdays = [w for w in DEFAULT_WEEKDAYS if w not in days_order]
            while len(days_order) < 7:
                pad_name = known_weekdays.pop(0) if known_weekdays else f"Day {len(days_order) + 1}"
                days_order.append(pad_name)
                day_records[pad_name] = {}

        daily_matrices = []
        day_names = []
        structured_rows = []
        observations_list = []

        for d_num, d_name in enumerate(days_order, start=1):
            services_in_day = day_records.get(d_name, {})
            day_matrix = np.zeros((4, 4), dtype=int)

            for s_idx, s_name in enumerate(REQUIRED_SERVICES):
                # Auto-fill missing services with 0 demand
                counts = services_in_day.get(s_name, [0, 0, 0, 0])
                day_matrix[s_idx, :] = counts

                structured_rows.append({
                    "day_number": d_num,
                    "day_name": str(d_name),
                    "service": s_name,
                    "slot_9_11": counts[0],
                    "slot_11_1": counts[1],
                    "slot_1_4": counts[2],
                    "slot_4_6": counts[3]
                })

            daily_matrices.append(day_matrix)
            day_names.append(str(d_name))

            for j in range(4):
                obs_vector = day_matrix[:, j]
                observations_list.append(obs_vector)

        observations_array = np.array(observations_list, dtype=float)

        return daily_matrices, day_names, observations_array, structured_rows
