import json
import numpy as np
from fastapi import FastAPI, UploadFile, File, Form, Depends, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional, Dict, Any

from app.config import settings
from app.models import (
    CalculationResult,
    DatasetAssumptions,
    DatasetResponse,
    WeekComparisonResponse,
    WeekComparisonItem,
    AdvancedAnalysisResult,
    PrinterMetrics,
    StaffMetrics
)
from app.math_engine import MathEngine, SERVICE_NAMES, TIME_SLOT_LABELS
from app.csv_parser import CSVParser
from app.insights_engine import InsightsEngine
from app.supabase_client import supabase_service
from app.auth import get_current_user_optional, get_current_user
from app.sample_data import get_sample_csv_text, SAMPLE_DATA_ROWS

app = FastAPI(
    title="BQ PRINTERS — Demand Analytics API",
    description="Mathematical computation engine & demand analyzer for printing shops based on academic linear algebra models.",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def run_full_pipeline(
    daily_matrices: List[np.ndarray],
    day_names: List[str],
    observations: np.ndarray,
    assumptions: DatasetAssumptions
) -> CalculationResult:
    """
    Executes the entire mathematical pipeline strictly following the academic report.
    """
    # 1. Weekly Matrix W
    W = MathEngine.compute_weekly_matrix(daily_matrices)

    # 2. Service totals and percentages
    service_totals, service_percentages, N = MathEngine.compute_service_totals_and_percentages(W)
    avg_daily_demand = MathEngine.compute_average_daily_demand(N)
    avg_matrix = MathEngine.compute_average_demand_matrix(W)

    # Top Service
    top_service_name = max(service_totals.items(), key=lambda x: x[1], default=("B&W Printing", 0))[0]
    top_service = {
        "name": top_service_name,
        "total_demand": service_totals.get(top_service_name, 0),
        "percentage": service_percentages.get(top_service_name, 0.0)
    }

    # 3. Time slot metrics
    slot_durations = [2.0, 2.0, 3.0, 2.0]
    timeslot_totals, duration_adjusted_rates, peak_slot, peak_rate = MathEngine.compute_timeslot_metrics(
        W, slot_durations=slot_durations
    )
    peak_time_slot = {
        "label": peak_slot,
        "total_demand": timeslot_totals[peak_slot],
        "rate_per_hour": peak_rate
    }

    # 4. Daily demand comparisons and matrix rank
    daily_totals, busiest_day, least_busy_day, matrix_rank, M = MathEngine.compute_daily_totals_and_rank(
        daily_matrices, day_names
    )

    # 5 & 6. Covariance, Correlation, and Eigenvalues
    mean_vec, cov_mat, corr_mat, evals, evecs, var_explained = MathEngine.compute_covariance_and_eigenvalues(
        observations
    )

    # Standardize sign: ensure primary eigenvector has positive loading on primary service
    if evecs.shape[1] > 0 and evecs[0, 0] < 0:
        evecs[:, 0] = -evecs[:, 0]

    # Covariance & Correlation dict mappings
    cov_dict = {}
    corr_dict = {}
    for i, s1 in enumerate(SERVICE_NAMES):
        cov_dict[s1] = {}
        corr_dict[s1] = {}
        for j, s2 in enumerate(SERVICE_NAMES):
            cov_dict[s1][s2] = round(float(cov_mat[i, j]), 3)
            corr_dict[s1][s2] = round(float(corr_mat[i, j]), 3)

    mean_vector_dict = {
        SERVICE_NAMES[i]: round(float(mean_vec[i]), 2) for i in range(4)
    }

    dominant_dir_desc = (
        f"Primary eigenvector explains {var_explained[0]:.2f}% of variance. "
        f"Direction: B&W ({evecs[0, 0]:.2f}), Colour ({evecs[1, 0]:.2f}), "
        f"Binding ({evecs[2, 0]:.2f}), Photocopying ({evecs[3, 0]:.2f}). "
        "Positive loadings across all services confirm a dominant general shop-wide traffic factor."
    )

    advanced_analysis = AdvancedAnalysisResult(
        matrix_rank=matrix_rank,
        mean_vector=mean_vector_dict,
        covariance_matrix=cov_dict,
        correlation_matrix=corr_dict,
        eigenvalues=[round(float(v), 3) for v in evals],
        variance_explained=[round(float(v), 2) for v in var_explained],
        eigenvectors=[[round(float(val), 3) for val in row] for row in evecs.tolist()],
        dominant_direction=dominant_dir_desc
    )

    # 7. Printer capacity
    op_hours = [assumptions.daily_operating_hours] * 7
    printer_res = MathEngine.compute_printer_capacity(
        service_totals=service_totals,
        operating_hours_per_day=op_hours,
        hp_rated_ppm=assumptions.hp_rated_ppm,
        canon_rated_ipm=assumptions.canon_rated_ipm,
        pages_per_order=assumptions.pages_per_order
    )
    printer_metrics = PrinterMetrics(**printer_res)

    # 8. Staff availability & workload
    staff_counts = [assumptions.staff_count] * 7
    staff_handling = {
        "B&W Printing": assumptions.handling_time_min.get("bw", 2.0),
        "Colour Printing": assumptions.handling_time_min.get("colour", 4.0),
        "Binding": assumptions.handling_time_min.get("binding", 8.0),
        "Photocopying": assumptions.handling_time_min.get("photocopying", 2.0)
    }
    staff_res = MathEngine.compute_staff_workload(
        service_totals=service_totals,
        daily_matrices=daily_matrices,
        day_names=day_names,
        staff_counts=staff_counts,
        operating_hours_per_day=op_hours,
        handling_times=staff_handling
    )
    staff_metrics = StaffMetrics(**staff_res)

    # 9. Business Recommendations
    recommendations = InsightsEngine.generate_recommendations(
        service_percentages=service_percentages,
        peak_time_slot=peak_slot,
        peak_rate=peak_rate,
        duration_adjusted_rates=duration_adjusted_rates,
        busiest_day=busiest_day,
        least_busy_day=least_busy_day,
        printer_metrics=printer_res,
        staff_metrics=staff_res,
        variance_explained=[float(v) for v in var_explained]
    )

    return CalculationResult(
        total_weekly_demand=N,
        average_daily_demand=avg_daily_demand,
        top_service=top_service,
        peak_time_slot=peak_time_slot,
        weekly_matrix=W.tolist(),
        average_daily_matrix=avg_matrix.tolist(),
        service_totals=service_totals,
        service_percentages=service_percentages,
        timeslot_totals=timeslot_totals,
        duration_adjusted_rates=duration_adjusted_rates,
        daily_totals=daily_totals,
        busiest_day=busiest_day,
        least_busy_day=least_busy_day,
        printer_metrics=printer_metrics,
        staff_metrics=staff_metrics,
        advanced_analysis=advanced_analysis,
        recommendations=recommendations
    )

@app.get("/api/health")
def health_check():
    return {
        "status": "healthy",
        "service": "BQ PRINTERS Demand Analytics Engine",
        "supabase_connected": supabase_service.is_available()
    }

@app.get("/api/sample-dataset")
def get_sample_dataset(format: str = "csv"):
    """
    Returns the authoritative academic benchmark dataset from the project report.
    """
    if format == "csv":
        return {"csv": get_sample_csv_text()}
    return {"rows": SAMPLE_DATA_ROWS}

@app.post("/api/analyze-csv", response_model=Dict[str, Any])
async def analyze_csv(
    file: UploadFile = File(...),
    dataset_name: Optional[str] = Form(None),
    week_label: Optional[str] = Form(None),
    notes: Optional[str] = Form(None),
    save_to_supabase: bool = Form(True),
    assumptions_json: Optional[str] = Form(None),
    user: Optional[Dict[str, Any]] = Depends(get_current_user_optional)
):
    """
    Main endpoint for CSV upload and analysis.
    Validates CSV, computes all linear algebra and operational formulas,
    saves the dataset and math results into Supabase PostgreSQL,
    and returns comprehensive dashboard analytics.
    """
    contents = await file.read()
    csv_text = contents.decode("utf-8", errors="replace")

    # 1. Parse and validate CSV
    try:
        daily_matrices, day_names, observations, structured_rows = CSVParser.parse_and_validate(csv_text)
    except ValueError as ve:
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to process CSV file: {str(e)}")

    # 2. Parse assumptions
    assumptions = DatasetAssumptions()
    if assumptions_json:
        try:
            parsed_assump = json.loads(assumptions_json)
            assumptions = DatasetAssumptions(**parsed_assump)
        except Exception as e:
            pass  # Fallback to default assumptions

    if notes:
        assumptions.notes = notes
        assumptions.operational_notes = notes

    # 3. Run Math Engine Pipeline
    try:
        calc_results = run_full_pipeline(daily_matrices, day_names, observations, assumptions)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Mathematical calculation failed: {str(e)}")

    dataset_id = "local-preview-id"
    created_at_str = ""

    # 4. Save to Supabase if requested and client is ready
    if save_to_supabase and supabase_service.is_available():
        name = dataset_name or file.filename or "Weekly Demand Analysis"
        user_id = user.get("id") if user else None
        try:
            ds_record = supabase_service.create_dataset(
                dataset_name=name,
                user_id=user_id,
                week_label=week_label,
                total_demand=calc_results.total_weekly_demand
            )
            dataset_id = ds_record["id"]
            created_at_str = ds_record.get("created_at", "")

            # Insert observations, assumptions, calculations
            supabase_service.insert_observations(dataset_id, structured_rows)
            supabase_service.insert_assumptions(dataset_id, assumptions.dict())
            supabase_service.insert_calculations(dataset_id, calc_results.dict())
        except Exception as e:
            # Clean up incomplete dataset record to prevent orphaned state
            if dataset_id != "local-preview-id":
                try:
                    supabase_service.delete_dataset(dataset_id)
                except Exception:
                    pass
                dataset_id = "local-preview-id"
            print(f"Warning: Supabase write failed: {e}")

    return {
        "dataset_id": dataset_id,
        "dataset_name": dataset_name or file.filename or "Uploaded Week",
        "week_label": week_label or "Analyzed Week",
        "created_at": created_at_str,
        "calculations": calc_results.dict(),
        "assumptions": assumptions.dict()
    }

@app.get("/api/datasets", response_model=List[Dict[str, Any]])
def list_datasets(user: Optional[Dict[str, Any]] = Depends(get_current_user_optional)):
    """
    Lists historical datasets stored in Supabase.
    """
    user_id = user.get("id") if user else None
    return supabase_service.list_datasets(user_id=user_id)

@app.get("/api/datasets/{dataset_id}")
def get_dataset(dataset_id: str):
    """
    Retrieves full details and calculations for a historical dataset.
    """
    details = supabase_service.get_dataset_details(dataset_id)
    if not details:
        raise HTTPException(status_code=404, detail=f"Dataset {dataset_id} not found.")
    return details

@app.delete("/api/datasets/{dataset_id}")
def delete_dataset(dataset_id: str):
    """
    Deletes a dataset and its cascading calculations.
    """
    success = supabase_service.delete_dataset(dataset_id)
    if not success:
        raise HTTPException(status_code=500, detail="Failed to delete dataset.")
    return {"deleted": True, "dataset_id": dataset_id}

@app.post("/api/compare-weeks", response_model=WeekComparisonResponse)
def compare_weeks(dataset_ids: List[str]):
    """
    Accepts 2 or more Dataset IDs, loads their calculations,
    and computes absolute and percentage differences across demand and workloads.
    """
    if len(dataset_ids) < 2:
        raise HTTPException(status_code=400, detail="Please provide at least 2 dataset IDs to compare.")

    datasets_list = []
    for d_id in dataset_ids:
        details = supabase_service.get_dataset_details(d_id)
        if not details or not details.get("calculations"):
            continue
        ds = details["dataset"]
        calc = details["calculations"]

        datasets_list.append(WeekComparisonItem(
            dataset_id=d_id,
            dataset_name=ds.get("dataset_name", "Week"),
            week_label=ds.get("week_label", ""),
            total_demand=int(np.sum(calc["weekly_matrix"])) if calc.get("weekly_matrix") is not None else int(ds.get("total_demand", 0)),
            average_daily_demand=round(float(ds.get("total_demand", 0)) / 7.0, 2),
            peak_time_slot=max(calc.get("timeslot_totals", {}).items(), key=lambda x: x[1], default=("11 AM–1 PM", 0))[0],
            top_service=max(calc.get("service_totals", {}).items(), key=lambda x: x[1], default=("B&W Printing", 0))[0],
            busiest_day=max(calc.get("daily_totals", []), key=lambda x: x.get("total_demand", 0), default={"day_name": "Thursday"}).get("day_name", "Thursday"),
            hp_load_ratio=float(calc.get("printer_metrics", {}).get("hp_laser_303dw", {}).get("load_ratio_percent", 0.0)),
            canon_load_ratio=float(calc.get("printer_metrics", {}).get("canon_pixma_g670", {}).get("load_ratio_percent", 0.0)),
            staff_utilization=float(calc.get("staff_metrics", {}).get("weekly_utilization_percent", 0.0))
        ))

    if len(datasets_list) < 2:
        raise HTTPException(status_code=400, detail="Not enough valid datasets found for comparison.")

    # Compare baseline (first) with latest (last)
    base = datasets_list[0]
    latest = datasets_list[-1]

    abs_diff = {
        "total_demand": latest.total_demand - base.total_demand,
        "average_daily_demand": round(latest.average_daily_demand - base.average_daily_demand, 2),
        "hp_load_ratio": round(latest.hp_load_ratio - base.hp_load_ratio, 2),
        "canon_load_ratio": round(latest.canon_load_ratio - base.canon_load_ratio, 2),
        "staff_utilization": round(latest.staff_utilization - base.staff_utilization, 2)
    }

    pct_diff = {
        "total_demand": round(((latest.total_demand - base.total_demand) / base.total_demand) * 100.0, 2) if base.total_demand > 0 else 0.0,
        "average_daily_demand": round(((latest.average_daily_demand - base.average_daily_demand) / base.average_daily_demand) * 100.0, 2) if base.average_daily_demand > 0 else 0.0,
        "staff_utilization": round(((latest.staff_utilization - base.staff_utilization) / base.staff_utilization) * 100.0, 2) if base.staff_utilization > 0 else 0.0
    }

    insights = []
    if abs_diff["total_demand"] > 0:
        insights.append(f"Overall demand grew by {abs_diff['total_demand']} orders (+{pct_diff['total_demand']}%).")
    elif abs_diff["total_demand"] < 0:
        insights.append(f"Overall demand softened by {abs(abs_diff['total_demand'])} orders ({pct_diff['total_demand']}%).")
    else:
        insights.append("Total customer demand remained steady across weeks.")

    if abs_diff["staff_utilization"] > 5.0:
        insights.append(f"Staff workload intensity increased by +{abs_diff['staff_utilization']} percentage points.")
    
    return WeekComparisonResponse(
        datasets=datasets_list,
        absolute_differences=abs_diff,
        percentage_differences=pct_diff,
        summary_insights=insights
    )
