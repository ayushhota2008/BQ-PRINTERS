import numpy as np
from typing import List, Dict, Tuple, Any

SERVICE_NAMES = [
    "B&W Printing",
    "Colour Printing",
    "Binding",
    "Photocopying"
]

TIME_SLOT_LABELS = [
    "9 AM–11 AM",
    "11 AM–1 PM",
    "1 PM–4 PM",
    "4 PM–6 PM"
]

DEFAULT_SLOT_DURATIONS = [2.0, 2.0, 3.0, 2.0]  # in hours

class MathEngine:
    """
    Authoritative Mathematical Engine for BQ PRINTERS Demand Analytics.
    Implements all formulas strictly from the academic project report:
    'Printing Shop Demand Analyzer' using NumPy and linear algebra.
    """

    @staticmethod
    def compute_weekly_matrix(daily_matrices: List[np.ndarray]) -> np.ndarray:
        """
        Step 1: Weekly demand matrix:
        W = \\sum_{d=1}^7 D_d
        Shape: (4, 4)
        """
        if len(daily_matrices) != 7:
            raise ValueError(f"Expected 7 daily matrices, got {len(daily_matrices)}")
        
        W = np.zeros((4, 4), dtype=int)
        for D_d in daily_matrices:
            if D_d.shape != (4, 4):
                raise ValueError(f"Each daily matrix must be 4x4, got {D_d.shape}")
            W += D_d
        return W

    @staticmethod
    def compute_service_totals_and_percentages(W: np.ndarray) -> Tuple[Dict[str, int], Dict[str, float], int]:
        """
        Step 2: Service totals R_i and percentage demand P_i
        R_i = \\sum_{j=1}^4 W_{ij}
        N = \\sum_{i=1}^4 R_i
        P_i = (R_i / N) * 100%
        """
        row_totals = np.sum(W, axis=1)
        N = int(np.sum(W))
        if N == 0:
            return {s: 0 for s in SERVICE_NAMES}, {s: 0.0 for s in SERVICE_NAMES}, 0

        service_totals = {}
        service_percentages = {}
        for idx, s_name in enumerate(SERVICE_NAMES):
            total_val = int(row_totals[idx])
            service_totals[s_name] = total_val
            service_percentages[s_name] = round((total_val / N) * 100.0, 2)

        return service_totals, service_percentages, N

    @staticmethod
    def compute_average_daily_demand(N: int) -> float:
        """
        Step 2: Average daily demand:
        \\bar{N} = N / 7
        """
        return round(N / 7.0, 2)

    @staticmethod
    def compute_average_demand_matrix(W: np.ndarray) -> np.ndarray:
        """
        Step 2: Average demand matrix:
        \\bar{D} = W / 7
        """
        return np.round(W / 7.0, 2)

    @staticmethod
    def compute_timeslot_metrics(
        W: np.ndarray, 
        slot_durations: List[float] = DEFAULT_SLOT_DURATIONS
    ) -> Tuple[Dict[str, int], Dict[str, float], str, float]:
        """
        Step 3: Column totals C_j and duration-adjusted demand rates Q_j:
        C_j = \\sum_{i=1}^4 W_{ij}
        C_{max} = max_{j} C_j
        Q_j = C_j / (7 * h_j) where h_j is the duration in hours
        """
        col_totals = np.sum(W, axis=0)
        timeslot_totals = {}
        duration_adjusted_rates = {}

        for j, slot in enumerate(TIME_SLOT_LABELS):
            c_val = int(col_totals[j])
            h_j = slot_durations[j]
            timeslot_totals[slot] = c_val
            # Duration-adjusted rate across 7 days
            q_val = round(c_val / (7.0 * h_j), 2)
            duration_adjusted_rates[slot] = q_val

        # Peak time slot based on total demand
        peak_idx = int(np.argmax(col_totals))
        peak_slot = TIME_SLOT_LABELS[peak_idx]
        peak_rate = duration_adjusted_rates[peak_slot]

        return timeslot_totals, duration_adjusted_rates, peak_slot, peak_rate

    @staticmethod
    def compute_daily_totals_and_rank(
        daily_matrices: List[np.ndarray],
        day_names: List[str]
    ) -> Tuple[List[Dict[str, Any]], Dict[str, Any], Dict[str, Any], int, np.ndarray]:
        """
        Step 4: Daily totals N_d, max and min daily demands, 7x16 matrix M, and rank(M).
        N_d = \\sum_{i=1}^4 \\sum_{j=1}^4 (D_d)_{ij}
        M = [row_1; ...; row_7]_{7 x 16}
        rank(M)
        """
        daily_totals = []
        rows_for_M = []

        for d_idx, D_d in enumerate(daily_matrices):
            tot = int(np.sum(D_d))
            d_name = day_names[d_idx] if d_idx < len(day_names) else f"Day {d_idx + 1}"
            daily_totals.append({
                "day_number": d_idx + 1,
                "day_name": d_name,
                "total_demand": tot
            })
            rows_for_M.append(D_d.flatten())

        M = np.array(rows_for_M, dtype=float)
        matrix_rank = int(np.linalg.matrix_rank(M))

        totals_array = [d["total_demand"] for d in daily_totals]
        max_idx = int(np.argmax(totals_array))
        min_idx = int(np.argmin(totals_array))

        busiest_day = daily_totals[max_idx]
        least_busy_day = daily_totals[min_idx]

        return daily_totals, busiest_day, least_busy_day, matrix_rank, M

    @staticmethod
    def compute_covariance_and_eigenvalues(
        observations: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """
        Step 5 & 6:
        Observation vectors x_n = [b_n, c_n, g_n, p_n]^T for n=1..28 (7 days * 4 slots)
        Mean vector: \\bar{x} = (1 / 28) \\sum x_n
        Sample covariance matrix: S = (1 / 27) \\sum (x_n - \\bar{x})(x_n - \\bar{x})^T
        Correlation matrix: R_{ik} = S_{ik} / sqrt(S_{ii} * S_{kk})
        Eigenvalues: det(S - \\lambda I) = 0
        Eigenvectors: S = P \\Lambda P^T
        Variance explained: E_k = (\\lambda_k / \\sum \\lambda_j) * 100%
        """
        if observations.shape != (28, 4):
            raise ValueError(f"Expected observations shape (28, 4), got {observations.shape}")

        # Mean vector (4,)
        mean_vec = np.mean(observations, axis=0)

        # Sample covariance with ddof=1 (N-1 in denominator)
        cov_matrix = np.cov(observations, rowvar=False, ddof=1)

        # Correlation matrix
        corr_matrix = np.corrcoef(observations, rowvar=False)

        # Eigenvalue decomposition for symmetric real matrix
        evals, evecs = np.linalg.eigh(cov_matrix)

        # Sort descending
        idx_sorted = np.argsort(evals)[::-1]
        sorted_evals = evals[idx_sorted]
        sorted_evecs = evecs[:, idx_sorted]

        # Variance explained
        total_variance = np.sum(sorted_evals)
        if total_variance > 0:
            var_explained = (sorted_evals / total_variance) * 100.0
        else:
            var_explained = np.zeros_like(sorted_evals)

        return mean_vec, cov_matrix, corr_matrix, sorted_evals, sorted_evecs, var_explained

    @staticmethod
    def compute_printer_capacity(
        service_totals: Dict[str, int],
        operating_hours_per_day: List[float],
        hp_rated_ppm: float = 30.0,
        canon_rated_ipm: float = 3.9,
        pages_per_order: Dict[str, int] = None
    ) -> Dict[str, Any]:
        """
        Step 3A: Printer capacity and estimated workload.
        HP Laser 303dw: C_HP = 30 * 60 = 1800 pages/hour
        Canon MegaTank G670: C_Canon = 3.9 * 60 = 234 images/hour
        K = C * H
        Estimated page demand: P_i = D_i * m_i
        Planning pages per order: B&W=4, Colour=3, Photocopying=5
        Load ratio: \\rho = (P / K) * 100%
        """
        if pages_per_order is None:
            pages_per_order = {"bw": 4, "colour": 3, "photocopying": 5, "binding": 0}

        c_hp_hourly = hp_rated_ppm * 60.0
        c_canon_hourly = canon_rated_ipm * 60.0

        total_hours = sum(operating_hours_per_day)

        k_hp_weekly = c_hp_hourly * total_hours
        k_canon_weekly = c_canon_hourly * total_hours

        bw_orders = service_totals.get("B&W Printing", 0)
        colour_orders = service_totals.get("Colour Printing", 0)
        photocopy_orders = service_totals.get("Photocopying", 0)

        p_bw_pages = bw_orders * pages_per_order.get("bw", 4)
        p_colour_pages = colour_orders * pages_per_order.get("colour", 3)
        p_photo_pages = photocopy_orders * pages_per_order.get("photocopying", 5)

        rho_hp = round((p_bw_pages / k_hp_weekly) * 100.0, 2) if k_hp_weekly > 0 else 0.0
        rho_canon = round((p_colour_pages / k_canon_weekly) * 100.0, 2) if k_canon_weekly > 0 else 0.0

        return {
            "hp_laser_303dw": {
                "model_name": "HP Laser 303dw",
                "rated_ppm": hp_rated_ppm,
                "hourly_capacity": int(c_hp_hourly),
                "weekly_capacity": int(k_hp_weekly),
                "allocated_service": "B&W Printing",
                "weekly_orders": bw_orders,
                "pages_per_order": pages_per_order.get("bw", 4),
                "estimated_pages": p_bw_pages,
                "load_ratio_percent": rho_hp,
                "status": "Optimal" if rho_hp < 75.0 else ("Warning" if rho_hp < 95.0 else "Critical")
            },
            "canon_pixma_g670": {
                "model_name": "Canon PIXMA MegaTank G670",
                "rated_ipm": canon_rated_ipm,
                "hourly_capacity": round(c_canon_hourly, 1),
                "weekly_capacity": int(k_canon_weekly),
                "allocated_service": "Colour Printing",
                "weekly_orders": colour_orders,
                "pages_per_order": pages_per_order.get("colour", 3),
                "estimated_pages": p_colour_pages,
                "load_ratio_percent": rho_canon,
                "status": "Optimal" if rho_canon < 75.0 else ("Warning" if rho_canon < 95.0 else "Critical")
            },
            "photocopying_standalone": {
                "service": "Photocopying",
                "weekly_orders": photocopy_orders,
                "pages_per_order": pages_per_order.get("photocopying", 5),
                "estimated_pages": p_photo_pages,
                "note": "Treated as standalone multifunction printer workload in accordance with academic project report."
            },
            "assumptions": {
                "operating_hours_per_day": operating_hours_per_day,
                "total_weekly_hours": total_hours,
                "pages_per_order": pages_per_order
            }
        }

    @staticmethod
    def compute_staff_workload(
        service_totals: Dict[str, int],
        daily_matrices: List[np.ndarray],
        day_names: List[str],
        staff_counts: List[int] = None,
        operating_hours_per_day: List[float] = None,
        handling_times: Dict[str, float] = None
    ) -> Dict[str, Any]:
        """
        Step 3B: Staff availability and estimated workload.
        Scheduled staff availability: A = s * H
        A_week = \\sum S_d * H_d (Default: 3 * 9 * 7 = 189 staff-hours)
        Handling times: B&W=2m, Colour=4m, Binding=8m, Photocopying=2m
        W = \\sum D_i * t_i (in minutes)
        W_hours = W / 60
        Workload ratio: u = (W_hours / A_week) * 100%
        Daily workload ratio: u_d = (W_d / A_d) * 100%
        """
        if staff_counts is None:
            staff_counts = [3] * 7
        if operating_hours_per_day is None:
            operating_hours_per_day = [9.0] * 7
        if handling_times is None:
            handling_times = {
                "B&W Printing": 2.0,
                "Colour Printing": 4.0,
                "Binding": 8.0,
                "Photocopying": 2.0
            }

        scheduled_weekly_hours = 3.0 * 9.0 * 7.0  # 189.0
        actual_available_weekly_hours = sum(s * h for s, h in zip(staff_counts, operating_hours_per_day))

        # Total workload in minutes
        total_workload_mins = 0.0
        service_workload_breakdown = {}
        for s_name in SERVICE_NAMES:
            orders = service_totals.get(s_name, 0)
            t_i = handling_times.get(s_name, 2.0)
            mins = orders * t_i
            total_workload_mins += mins
            service_workload_breakdown[s_name] = {
                "weekly_orders": orders,
                "handling_time_min": t_i,
                "estimated_minutes": round(mins, 1),
                "estimated_hours": round(mins / 60.0, 2)
            }

        total_workload_hours = round(total_workload_mins / 60.0, 2)
        weekly_utilization = round((total_workload_hours / actual_available_weekly_hours) * 100.0, 2) if actual_available_weekly_hours > 0 else 0.0

        # Daily breakdown
        daily_breakdown = []
        for d_idx, D_d in enumerate(daily_matrices):
            d_name = day_names[d_idx] if d_idx < len(day_names) else f"Day {d_idx + 1}"
            day_orders_per_service = np.sum(D_d, axis=1)  # row sums for that day
            day_workload_mins = sum(
                day_orders_per_service[i] * handling_times.get(SERVICE_NAMES[i], 2.0)
                for i in range(4)
            )
            day_workload_hours = round(day_workload_mins / 60.0, 2)
            avail_hours = staff_counts[d_idx] * operating_hours_per_day[d_idx]
            day_util = round((day_workload_hours / avail_hours) * 100.0, 2) if avail_hours > 0 else 0.0

            daily_breakdown.append({
                "day_number": d_idx + 1,
                "day_name": d_name,
                "staff_present": staff_counts[d_idx],
                "operating_hours": operating_hours_per_day[d_idx],
                "available_staff_hours": avail_hours,
                "workload_minutes": round(float(day_workload_mins), 1),
                "workload_hours": float(day_workload_hours),
                "utilization_percent": float(day_util),
                "is_overloaded": bool(day_util > 85.0)
            })

        return {
            "scheduled_availability_weekly_hours": scheduled_weekly_hours,
            "actual_available_weekly_hours": actual_available_weekly_hours,
            "total_workload_minutes": round(total_workload_mins, 1),
            "total_workload_hours": total_workload_hours,
            "weekly_utilization_percent": weekly_utilization,
            "service_workload_breakdown": service_workload_breakdown,
            "daily_breakdown": daily_breakdown,
            "assumptions": {
                "staff_counts": staff_counts,
                "operating_hours_per_day": operating_hours_per_day,
                "handling_times_min": handling_times
            }
        }
